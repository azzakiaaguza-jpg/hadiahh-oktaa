WEBSITE HADIAH UNTUK OKTAA / YAYAAAA

Cara mencoba:
1. Buka index.html di browser (Safari/Chrome) untuk melihat website.
2. Kode rahasia awal adalah 07092026. Ubah const SECRET_CODE di bagian JavaScript index.html menjadi tanggal spesial kalian, format DDMMYYYY.
3. Untuk mengganti surat, edit teks di dalam elemen <div class="letter">.
4. Untuk menambahkan foto, pengunjung bisa menekan kotak foto saat halaman hadiah terbuka. Foto diproses di browser, tidak diunggah ke server.

Cara publikasi gratis (contoh GitHub Pages):
1. Buat akun di github.com lalu buat repository baru bernama hadiah-oktaa.
2. Unggah index.html ke repository tersebut.
3. Buka Settings > Pages, pilih Deploy from a branch, pilih branch main dan folder /(root), lalu Save.
4. Tunggu beberapa menit sampai GitHub Pages memberi URL publik.

Catatan:
- Ini website statis tanpa server. Kode rahasia ada di JavaScript, jadi ini pengunci sederhana untuk kejutan, bukan keamanan sungguhan. Siapa pun yang memeriksa source code dapat menemukan kode tersebut.
- Sebelum dibagikan, ganti tanggal contoh dan sesuaikan isi surat agar benar-benar sesuai cerita kalian.
